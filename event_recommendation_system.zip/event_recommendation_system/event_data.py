#!/usr/bin/env python
# coding: utf-8

# In[18]:


import pandas as pd
df_type1=pd.read_csv('event_type.csv',encoding='latin1')


# In[19]:


import numpy as np
df_type2=df_type1.iloc[ : ,[1]]
df_type2=df_type2.replace(np.nan,'')
l1=list()
l1=df_type2.values.tolist()
df_type2['Ttotal']=pd.Series(l1).values
df_type2['Ttotal']=df_type2['Ttotal'].apply(set)



# In[20]:


df_domain1=pd.read_csv('event_domain.csv',encoding='latin1')


# In[21]:


df_domain2=df_domain1.iloc[ : ,[1]]
df_doamin2=df_domain2.replace(np.nan,'')
l2=list()
l2=df_domain2.values.tolist()
df_domain2['Dtotal']=pd.Series(l2).values
df_domain2['Dtotal']=df_domain2['Dtotal'].apply(set)


# In[22]:


import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import GlobalMaxPooling1D
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Embedding
from tensorflow.keras.layers import Input
from sklearn.preprocessing import MultiLabelBinarizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Activation, Dropout, Dense
from tensorflow.keras.layers import Flatten, LSTM
import sklearn.utils
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
nltk.download('stopwords')
from numpy import array
from numpy import asarray
from numpy import zeros


# In[23]:


mlb = MultiLabelBinarizer()
l_type=mlb.fit_transform(df_type2['Ttotal'])
df_type3=pd.DataFrame(l_type)
df_type3.columns=list(mlb.classes_)
data=pd.Series(df_type1['Event '])
df_type3.insert(0,'Event',data)
df_type3 = sklearn.utils.shuffle(df_type3)
df_type3 = df_type3.reset_index(drop=True)
df_type3.to_csv('df_type3.csv')


# In[24]:


l_domain=mlb.fit_transform(df_domain2['Dtotal'])
df_domain3=pd.DataFrame(l_domain)
df_domain3.columns=list(mlb.classes_)
data=pd.Series(df_domain1['Event'])
df_domain3.insert(0,'Event',data)
df_domain3 = sklearn.utils.shuffle(df_domain3)
df_domain3 = df_domain3.reset_index(drop=True)
df_domain3.to_csv('df_domain3.csv')


# In[ ]:





# In[ ]:




