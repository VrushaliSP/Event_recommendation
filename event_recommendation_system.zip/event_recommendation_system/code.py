#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Activation, Dropout, Dense
from tensorflow.keras.layers import Flatten, LSTM
from tensorflow.keras.layers import GlobalMaxPooling1D
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Embedding
from tensorflow.keras.layers import Input
from sklearn.preprocessing import MultiLabelBinarizer
import sklearn.utils
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
nltk.download('stopwords')
from numpy import array
from numpy import asarray
from numpy import zeros
nltk.download('punkt')


# In[3]:


event_type=pd.read_csv("df_type3.csv",encoding='latin1')
event_domain=pd.read_csv("df_domain3.csv",encoding='latin1')


# In[4]:


def data_preprocessing(sen):
    sentence =str(re.sub('[^0-9a-zA-Z]', ' ',str(sen)))
    sentence = re.sub(r"\s+[a-zA-Z]\s+", ' ', sentence)
    sentence = re.sub(r'\s+', ' ', sentence)
    sentence=str.lower(sentence)
    text_tokens = word_tokenize(sentence)
    tokens_without_sw = [word for word in text_tokens if not word in stopwords.words()]
    filtered_sentence = (" ").join(tokens_without_sw)
    return filtered_sentence


# In[5]:


x_type = []
x_domain=[]
sentences_type = list(event_type["Event"])
sentences_domain = list(event_domain["Event"])
for sen in sentences_type:
    x_type.append(data_preprocessing(sen))
for sen in sentences_domain:
    x_domain.append(data_preprocessing(sen))


# In[131]:


tokenizer_type = Tokenizer()
tokenizer_type.fit_on_texts(x_type)
X_data_type = tokenizer_type.texts_to_sequences(x_type)
vocab_size_type = len(tokenizer_type.word_index) + 1

tokenizer_domain= Tokenizer()
tokenizer_domain.fit_on_texts(x_domain)
X_data_domain = tokenizer_domain.texts_to_sequences(x_domain)
vocab_size_domain = len(tokenizer_domain.word_index) + 1

maxlen = 200
X_data_type = pad_sequences(X_data_type, padding='post', maxlen=maxlen)
X_data_domain = pad_sequences(X_data_domain, padding='post', maxlen=maxlen)


# In[132]:


type1=event_type[['Certifications','Competitions','Courses','Expos','Fests','Hackathons','Internships','Jobs','Talks','Trainings','Webinars','Workshops']]
domain=event_domain[['Artificial Intelligence' ,'Blockchain', 'C' ,'C++' ,'Cloud Computing',
 'Coding', 'Data Science', 'Finance' ,'Hardware',
 'Higher Education' ,'IoT', 'Java' ,'Javascript', 'Machine Learning',
 'Management' ,'Mobile Applications', 'Networking' ,'Other','Python',
 'Security' ,'Software Architecture', 'Web Development']]
y_type = type1.values
y_domain = domain.values


# In[8]:


embeddings_dictionary = dict()
glove_file = open('glove.6B.100d.txt', encoding="utf8")
for line in glove_file:
    records = line.split()
    word = records[0]
    vector_dimensions = asarray(records[1:], dtype='float32')
    embeddings_dictionary[word] = vector_dimensions
glove_file.close()

embedding_matrix_type = zeros((vocab_size_type, 100))
for word, index in tokenizer_type.word_index.items():
    embedding_vector_type = embeddings_dictionary.get(word)
    if embedding_vector_type is not None:
        embedding_matrix_type[index] = embedding_vector_type
        
embedding_matrix_domain = zeros((vocab_size_domain, 100))
for word, index in tokenizer_domain.word_index.items():
    embedding_vector_domain= embeddings_dictionary.get(word)
    if embedding_vector_domain is not None:
        embedding_matrix_domain[index] = embedding_vector_domain


# In[9]:


input_type = tf.keras.layers.Input(shape=(maxlen,))
x1= tf.keras.layers.Embedding(vocab_size_type,100, weights=[embedding_matrix_type], trainable=False)(input_type)
x1= tf.keras.layers.Bidirectional(tf.keras.layers.GRU(128, return_sequences=True, dropout=0.1,
                                                      recurrent_dropout=0.1))(x1)
x1= tf.keras.layers.Conv1D(64, kernel_size=3, padding="valid", kernel_initializer="glorot_uniform")(x1)
avg_pool_type = tf.keras.layers.GlobalAveragePooling1D()(x1)
max_pool_type = tf.keras.layers.GlobalMaxPooling1D()(x1)
x1 = tf.keras.layers.concatenate([avg_pool_type, max_pool_type])
preds_type = tf.keras.layers.Dense(12, activation="sigmoid")(x1)
model_type = tf.keras.Model(input_type, preds_type)


# In[10]:


model_type.compile(loss='binary_crossentropy', optimizer='adam' , metrics=['accuracy'])
history_type = model_type.fit(X_data_type, y_type,epochs=1, validation_split=0.2,class_weight='balanced')


# In[11]:


input_domain = tf.keras.layers.Input(shape=(maxlen,))
x2 = tf.keras.layers.Embedding(vocab_size_domain,100, weights=[embedding_matrix_domain], trainable=False)(input_domain)
x2 = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(128, return_sequences=True, dropout=0.1,
                                                      recurrent_dropout=0.1))(x2)
x2 = tf.keras.layers.Conv1D(64, kernel_size=3, padding="valid", kernel_initializer="glorot_uniform")(x2)
avg_pool_domain= tf.keras.layers.GlobalAveragePooling1D()(x2)
max_pool_domain = tf.keras.layers.GlobalMaxPooling1D()(x2)
x2 = tf.keras.layers.concatenate([avg_pool_domain, max_pool_domain])
preds_domain= tf.keras.layers.Dense(22, activation="sigmoid")(x2)
model_domain= tf.keras.Model(input_domain, preds_domain)


# In[12]:


model_domain.compile(loss='binary_crossentropy', optimizer='adam' , metrics=['accuracy'])
history2_domain= model_domain.fit(X_data_domain, y_domain,epochs=1, validation_split=0.2,class_weight='balanced')


# In[84]:


tokenizer = Tokenizer()
type_labels=['Certifications','Competitions','Courses','Expos','Fests','Hackathon','Internships','Jobs','Talks','Training','Webinars','Workshops']
domain_labels=['Artificial Intelligence' ,'Blockchain', 'C' ,'C++' ,'Cloud Computing',
 'Coding', 'Data Science','Finance' ,'Hardware',
 'Higher Education' ,'IoT', 'Java' ,'Javascript', 'Machine Learning',
 'Management' ,'Mobile Applications', 'Networking','Other','Python',
 'Security' ,'Software Architecture', 'Web Development']


# In[133]:


def event_classification(x) :
    event_set=pd.read_csv(x)
    sentences = list(event_set["Event"])
    variable=[]
    listT=[]
    listD=[]
    for sen in sentences:
        variable.append(data_preprocessing(sen))
    sen=data_preprocessing(sen)
    sen=np.array([sen])
    tokenizer.fit_on_texts(variable)
    sentence_data= tokenizer.texts_to_sequences(variable)
    maxlen = 200
    sentence_data = pad_sequences(sentence_data, padding='post', maxlen=maxlen)
    types=model_type.predict(sentence_data)
    domains=model_domain.predict(sentence_data)
    list1=np.argmax(types,axis=1)
    list2=np.argmax(domains,axis=1)
    for var in list1:
        listT.append(type_labels[var])
    for var in list2:
        listD.append(domain_labels[var])
    predict1(listT,listD)
    listE=predict1(listT,listT)
    variable1=[]
    for i in range(len(listE)):
        variable1.append(", ".join(listE[i]))
        event_set['Name']=pd.Series(variable1)
    print(event_set)
    event_set.to_excel("output.xlsx")


# In[134]:


def predict1(listT,listD) :
    listE=[]
    employee_data=pd.read_csv("CCMLEmployeeData.csv")
    for x in range(3) :
        variable3=[];
        for index, row in employee_data.iterrows():
            if(listD[x]!='Other'):
                if((row['Event1']==listT[x] or row['Event2']==listT[x])and row['Domain']==listD[x]):
                    variable3.append(row['Name'])
            else :
                if(row['Event1']==listT[x] or row['Event2']==listT[x]):
                    variable3.append(row['Name'])
        listE.append(variable3)
    return(listE)


# In[135]:


event_classification("test_data.csv")


# In[ ]:




